<?php

	include_once('conectar.php');
	include_once('funciones.php');

	if(!empty($_POST['accion']) && $_POST['accion'] == 'compra_cantidad'){
		
		$producto = $_POST['producto']; 
		$cantidad = $_POST['cantidad'];
		$subtotal = 0;
		
		$sql = "SELECT * FROM productos WHERE id = $producto ";
		$res = mysqli_query($conn, $sql);
		$reg = mysqli_fetch_assoc($res);
		
		$existencia = $reg['existencia'];
		$precio = $reg['precio'];
		
		if(is_numeric($cantidad)){
			if($cantidad <= $existencia){
				$subtotal = $cantidad*$precio;
				echo $subtotal;
			}else{
				echo 2;
			}
		}else{
			echo 1;
		}
		exit;
	}
	elseif(!empty($_POST['accion']) && $_POST['accion'] == 'finalizar'){
		
		$orden = $_POST['orden']; 
		$subtotal = $_POST['subtotal'];
		$iva = $_POST['iva'];
		$total = $_POST['total'];
		
		$sql = "INSERT INTO compras (nro_orden, subtotal, iva, total)
				VALUES ($orden, $subtotal, $iva, $total)";
		$res = mysqli_query($conn, $sql);
		echo $sql;
		exit;
	}

?>