<?php

	$conn = new mysqli("localhost", "root", "", "syam");
	if($conn->connect_errno) {
		echo "<br>Fallo al conectar a MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
	}/*else{
		echo "<br>Conectado";
	}*/

?>