<?php
	
	include('conectar.php');

	// funcion para guardar los productos leidos desde el json
	function guardarProducto($descripcion, $precio, $existencia){
		global $conn;
		
		// se valida que no existan datos vacios
		if($descripcion!="" && $precio>0 && $existencia>0){
			//valida existencia del producto
			$sql = "SELECT id FROM productos WHERE descripcion = '$descripcion' ";
			$res = mysqli_query($conn, $sql);
			$id_producto = 0;
			if(mysqli_num_rows($res) > 0){
				$reg = mysqli_fetch_assoc($res); 
				$id_producto = $reg['id'];
			}
			
			// si el producto no existe se inserta
			if($id_producto === 0){
				$sqlProd = "INSERT INTO productos (descripcion, precio, existencia, fecha)
						VALUES ('$descripcion', $precio, $existencia, NOW())";
			}else{
				// si el producto ya existe se actualiza 
				$sqlProd = "UPDATE productos 
						SET descripcion = '$descripcion', precio = $precio, existencia = $existencia, 
							fecha = NOW() 
						WHERE id = $id_producto 
					   ";
			}
			$resProd = mysqli_query($conn, $sqlProd);
			if($resProd === false){
				echo "<br>ERROR: No se pudo guardar el producto";	
			}

		}
	}
	
	// funcion que obtiene el nro de la orden consecutivo 
	function getNroOrden(){
		global $conn;
		
		$sql = "SELECT count(nro_orden) hay FROM compras";
		$res = mysqli_query($conn, $sql);
		$reg = mysqli_fetch_assoc($res);
		
		// al dato obtenido se suma uno para el siguiente consecutivo
		$nro_orden = $reg['hay'] + 1;
		// se retorna el nuevo numero
		return $nro_orden;
	}

	// funcion para obtener los articulos registrados en la tabla productos
	function getArticulos(){
		global $conn;
		
		$sql = "SELECT * FROM productos";
		$res = mysqli_query($conn, $sql);
		$opciones = "";
		while($reg = mysqli_fetch_assoc($res)){
			$opciones .= "<option value='".$reg['id']."'>".$reg['descripcion']."</option>";
		}
		return $opciones;
	}

?>