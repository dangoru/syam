
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Daniel Andres Gonzalez Ruiz</title>

	<link href='https://fonts.googleapis.com/css?family=Roboto:400,300,600,400italic,700' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Owl Carousel -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<!-- Theme style  -->
	<link rel="stylesheet" href="css/style.css">

	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->
		<script>
			var arrayItem = [];
			var arrayCantidad = [];
			var arraySubtotal = [];
			
			function validarCantidad(obj){
				var cantidad = obj.value;
				var producto = $('#articulo').val();
				
				if(producto == 0){
					alert('ERROR: Debe seleccionar un producto.');
				}else if(cantidad == 0){
					alert('ERROR: La cantidad debe ser mayor a cero.');
				}else{
					$.ajax({ 
						method: "POST", 
						url: "comprar_ajax.php", 
						data: {
							accion: 'compra_cantidad', 
							producto: producto, 
							cantidad: cantidad  
						}
					})
					.done(function(msg){
						if(msg == 1){ 
							alert('ERROR: La cantidad no es un numero valido.');
							$('#cantidad').val('0');
							$('#subtotal').val('0');
						}else if(msg == 2){ 
							alert('ERROR: La cantidad es mayor que la existencia');
							$('#cantidad').val('0');
							$('#subtotal').val('0');
						}else{
							$('#subtotal').val(msg);
						}
					});
				}
			}
			
			function validarNombre(){
				const nombre = document.getElementById('nombre');
				if(!nombre.checkValidity()){
					alert('ERROR: El nombre no es valido.');
					$('#nombre').val('');
					return false;
				}
				return true;
			}
			
			function validarNumero(){
				const cantidad = document.getElementById('cantidad');
				if(!cantidad.checkValidity()){
					alert('ERROR: La cantidad no es valida.');
					$('#cantidad').val('0');
					return false;
				}
				return true;
			}
			
			function agregarItem(){
				var fecha = $('#fecha').val();
				var nombre = $('#nombre').val();
				var articulo = $('#articulo').val();
				var cantidad = $('#cantidad').val();
				var subtotal = $('#subtotal').val();
				var fila = "";
				var antesiva = 0;
				
				if(nombre == ""){ alert('ERROR: Debe digitar el nombre.'); }
				else if(articulo == ""){ alert('ERROR: Debe seleccionar el articulo.'); }
				else if(cantidad == 0){ alert('ERROR: Debe digitar la cantidad.'); }
				else if(subtotal == 0){ alert('ERROR: Debe digitar el subtotal.'); }
				else{
					var tmp_articulo = document.getElementById('articulo');
					var texto_articulo = tmp_articulo.selectedOptions[0].text;
					
					fila += "<td class='col-md-3'>"+texto_articulo+"</td>"
					fila += "<td class='col-md-3'>"+cantidad+"</td>"
					fila += "<td class='col-md-3'>"+subtotal+"</td>"
					fila += "<td class='col-md-3'><img src='images/borrar.png' onclick='eliminarFila("+articulo+")' /></td>"
					
					document.getElementById("listado").insertRow(-1).innerHTML = fila;
					
					arrayItem.push(articulo);
					arrayCantidad.push(cantidad);
					arraySubtotal.push(subtotal);
					
					arraySubtotal.forEach(function(a){ antesiva += a;});
					
					var subIva = antesiva*(0.19);
					var total = antesiva+subIva;
					
					$('#subtotal').html(antesiva);
					$('#iva').html(subIva);
					$('#total').html(total);
				}
			}
			
			function eliminarFila(articulo){
				var table = document.getElementById("listado");
				var rowCount = table.rows.length;
				//console.log(rowCount);

				if(rowCount <= 1){}
				else{ table.deleteRow(rowCount -1); }
			}
			
			function finalizarCompra(){
				var orden_subtotal = 0;
				for(var i=0; i<arraySubtotal.length; i++){
					orden_subtotal += arraySubtotal[i];
				}
				
				var orden = $('#nro_orden').val();
				var orden_iva = orden_subtotal*(0.19);
				var orden_total = orden_subtotal+orden_iva;
				
				$.ajax({ 
					method: "POST", 
					url: "comprar_ajax.php", 
					data: {
						accion: 'finalizar', 
						orden: orden, 
						subtotal: orden_subtotal, 
						iva: orden_iva,
						total: orden_total 
					}
				})
				.done(function(msg){
					window.location = "index.php";
				});
			}
		</script>

	</head>
	<body>
	<?php
		include_once('funciones.php');
		
		date_default_timezone_set('America/Bogota');
	?>

	<div id="fh5co-page">
		<a href="#" class="js-fh5co-nav-toggle fh5co-nav-toggle"><i></i></a>
		<aside id="fh5co-aside" role="complementary" class="border js-fullheight">

			<h1 id="fh5co-logo"><a href="index.php">Daniel Andr&eacute;s Gonz&aacute;lez Ruiz</a></h1>
			<nav id="fh5co-main-menu" role="navigation">
				<ul>
					<li class="fh5co-active"><a href="index.php">Inicio</a></li>
					<li><a href="comprar.php">Comprar</a></li>
					<li><a href="total_compras.php">Total Compras</a></li>
				</ul>
			</nav>
		</aside>

		<div id="fh5co-main">

			<div class="fh5co-narrow-content">
				<h2 class="fh5co-heading animate-box" data-animate-effect="fadeInLeft">Compras</h2>
			</div>

			<div class="fh5co-narrow-content">
				<div class="col-md-12">
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								Nro. Orden: 
								<input type="text" class="form-control" name="nro_orden" id="nro_orden"  value="<?=getNroOrden()?>" readonly/>
							</div>
							<div class="form-group">
								Fecha: 
								<input type="text" class="form-control" name="fecha" id="fecha" value="<?=date('Y/m/d H/i');?>" readonly />
							</div>
							<div class="form-group">
								Nombre: 
								<input type="text" class="form-control" name="nombre" id="nombre" value=""  pattern="^[A-Za-z]+$" maxlength="100" onKeyUp="validarNombre();" onBlur="validarNombre();" />
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								Art&iacute;culo: 
								<select class="form-control" name="articulo" id="articulo">
									<option value="">Escoja un art&iacute;culo</option>
									<?=getArticulos();?>
								</select>
							</div>
							<div class="form-group">
								Cantidad: 
								<input type="text" class="form-control" name="cantidad" id="cantidad" value="0" pattern="^[0-9]+" onKeyUp="if(validarNumero()){ validarCantidad(this); }" onBlur="if(validarNumero()){ validarCantidad(this); }" /> 
							</div>
							<div class="form-group">
								Subtotal: 
								<input type="text" class="form-control" name="subtotal" id="subtotal" value="0" pattern="^[0-9]+" onKeyUp="validarNumero();"  onBlur="validarNumero();" />
							</div>
							<div class="form-group">
								<input type="button" class="btn btn-primary btn-md" value="Agregar Item" onClick="agregarItem();" />
							</div>
						</div>
					</div>
				</div>
			</div>
			<br><br>
			<div class="fh5co-narrow-content">
				<div class="col-md-12">
					<table id="listado" align="center" class="col-md-12">
						<thead>
							<tr bgcolor="#fcf8e3">
								<th class="col-md-3"><strong>ARTICULO</strong></th>
								<th class="col-md-3"><strong>CANTIDAD</strong></th>
								<th class="col-md-3"><strong>SUBTOTAL</strong></th>
								<th class="col-md-3"><strong>BORRAR ITEM</strong></th>
							</tr>
						</thead>
						<tbody></tbody>
					</table>
				</div>
			</div>
			
			<div class="fh5co-narrow-content">
				<div class="col-md-12">
					<table>
						<tr>
							<td class="bg-warning">SUBTOTAL: $ </td>
							<td id="subtotal"></td>
						</tr>
						<tr>
							<td class="bg-warning">TOTAL IVA: $ </td>
							<td id="iva"></td>
						</tr>
						<tr>
							<td class="bg-warning">TOTAL: $ </td>
							<td id="total"></td>
						</tr>
					</table>
				</div>
			</div>
			
			<div class="fh5co-narrow-content">
				<div class="col-md-12">
					<div class="row">
						<div class="col-md-6">
							<input type="button" class="btn btn-primary btn-md" value="Finalizar Compra" onClick="finalizarCompra();" />
						</div>
					</div>
				</div>
			</div>

		</div>
	</div>

	<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Carousel -->
	<script src="js/owl.carousel.min.js"></script>
	<!-- Stellar -->
	<script src="js/jquery.stellar.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Counters -->
	<script src="js/jquery.countTo.js"></script>
	
	
	
	<!-- MAIN JS -->
	<script src="js/main.js"></script>

	</body>
</html>

